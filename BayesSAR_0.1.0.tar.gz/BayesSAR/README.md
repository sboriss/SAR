
<!-- README.md is generated from README.Rmd. Please edit that file -->
BayesSAR
========

The goal of BayesSAR is to estimate a Spatial AutoRegressive (SAR) model using the Bayesian approach.

Installation
------------

The package is not ready yet. You cannot install the released version of BayesSAR from [CRAN](https://CRAN.R-project.org) with this command:

``` r
install.packages("BayesSAR")
```

Example
-------

This is a basic example illustrating the use of the package:

Options for data generation:

``` r
opt_model       = list()
opt_model$n     = 400
opt_model$phi   = 0.2
opt_model$mu    = 10
opt_model$sigm2 = 2

opt_model$only_incpt = FALSE # TRUE #

if( opt_model$only_incpt ){
  opt_model$beta = c( opt_model$mu ) %>% matrix( ncol = 1 )
}else{
  opt_model$beta = c( opt_model$mu, rep( 1, 2 ) ) %>% matrix( ncol = 1 )
}
```

What is special about using `README.Rmd` instead of just `README.md`? You can include R chunks like so:

``` r
### generate data
mW = createWeightMatrix( opt_model$n )

mB = mW * opt_model$phi

mCov = solve( diag( opt_model$n ) - mB ) %*% solve( diag( opt_model$n ) - t( mB ) ) * opt_model$sigm2

incpt <- rep( 1, opt_model$n)

if( opt_model$only_incpt ){
  mX = incpt %>% as.matrix %>% set_colnames( "incpt" )
}else{
  x1 = rep( seq( 1, sqrt( opt_model$n ) ), each = sqrt( opt_model$n ) )
  x2 = rep( seq( 1, sqrt( opt_model$n ) ), sqrt( opt_model$n ) )
  mX  = cbind( incpt, x1, x2 )
}

vE    <- rmvnorm( n=1, mean = rep(0, opt_model$n), sigma = mCov ) %>% t %>% as.data.frame
vY    <- mX %*% opt_model$beta + vE

dfYX = cbind( vY, mX ) %>% as.data.frame %>%
  set_colnames( c("y", colnames(mX) ) )

### OLS estimation as benchmark

text.ols = paste( colnames( dfYX )[1], paste( colnames( dfYX )[-1], collapse = "+" ), sep = "~" )
text.ols = paste0( text.ols, "-1")

formula.ols = as.formula( text.ols )

ols <- lm( formula.ols, data = dfYX ); summary( ols )
#> 
#> Call:
#> lm(formula = formula.ols, data = dfYX)
#> 
#> Residuals:
#>     Min      1Q  Median      3Q     Max 
#> -4.7381 -1.2177 -0.0735  1.2382  5.2354 
#> 
#> Coefficients:
#>       Estimate Std. Error t value Pr(>|t|)    
#> incpt 11.02671    0.25665   42.96   <2e-16 ***
#> x1     0.98352    0.01611   61.04   <2e-16 ***
#> x2     0.95044    0.01611   58.99   <2e-16 ***
#> ---
#> Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#> 
#> Residual standard error: 1.858 on 397 degrees of freedom
#> Multiple R-squared:  0.9967, Adjusted R-squared:  0.9967 
#> F-statistic: 4.032e+04 on 3 and 397 DF,  p-value: < 2.2e-16

### convert matrix to list
mWlist = mat2listw( mW, style="W"  )
summary( mWlist$neighbours )
#> Neighbour list object:
#> Number of regions: 400 
#> Number of nonzero links: 1520 
#> Percentage nonzero weights: 0.95 
#> Average number of links: 3.8 
#> Link number distribution:
#> 
#>   2   3   4 
#>   4  72 324 
#> 4 least connected regions:
#> 1 20 381 400 with 2 links
#> 324 most connected regions:
#> 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 82 83 84 85 86 87 88 89 90 91 92 93 94 95 96 97 98 99 102 103 104 105 106 107 108 109 110 111 112 113 114 115 116 117 118 119 122 123 124 125 126 127 128 129 130 131 132 133 134 135 136 137 138 139 142 143 144 145 146 147 148 149 150 151 152 153 154 155 156 157 158 159 162 163 164 165 166 167 168 169 170 171 172 173 174 175 176 177 178 179 182 183 184 185 186 187 188 189 190 191 192 193 194 195 196 197 198 199 202 203 204 205 206 207 208 209 210 211 212 213 214 215 216 217 218 219 222 223 224 225 226 227 228 229 230 231 232 233 234 235 236 237 238 239 242 243 244 245 246 247 248 249 250 251 252 253 254 255 256 257 258 259 262 263 264 265 266 267 268 269 270 271 272 273 274 275 276 277 278 279 282 283 284 285 286 287 288 289 290 291 292 293 294 295 296 297 298 299 302 303 304 305 306 307 308 309 310 311 312 313 314 315 316 317 318 319 322 323 324 325 326 327 328 329 330 331 332 333 334 335 336 337 338 339 342 343 344 345 346 347 348 349 350 351 352 353 354 355 356 357 358 359 362 363 364 365 366 367 368 369 370 371 372 373 374 375 376 377 378 379 with 4 links
```

What is special about using `README.Rmd` instead of just `README.md`? You can include R chunks like so:

``` r
opt_mc = list()
opt_mc$ini_iter = 200
opt_mc$max_iter = opt_mc$ini_iter + 200
opt_mc$mh_scale =0.035 #  1 # 
opt_mc$autotune = list( execute = FALSE, target_accept_MH = 0.33 ) #  TRUE #

y = dfYX[, 1] %>% as.matrix
x = dfYX[,-1] %>% as.matrix
w = mW
opt = opt_mc

ud = BayesSAR( opt, y, x, w )

### COLLECT THE RESULTS
sPhi    = lapply( ud$mc_list, `[[`, "sPhi"    ) %>% unlist
sLogD   = lapply( ud$mc_list, `[[`, "sLogD"   ) %>% unlist
sAccept = lapply( ud$mc_list, `[[`, "sAccept" ) %>% unlist
mBetaPhiHat = do.call( "cbind", lapply( ud$mc_list, `[[`, "vBetaPhiHat" ) )
mBeta       = do.call( "cbind", lapply( ud$mc_list, `[[`, "vBeta" ) )
sSigma2     = lapply( ud$mc_list, `[[`, "sSigma2" ) %>% unlist

if( opt_mc$autotune$execute ){
  sAccept_rate = lapply( ud$autotune_list, `[[`, "sAccept_rate"    ) %>% unlist
  mh_scale     = lapply( ud$autotune_list, `[[`, "mh_scale"    ) %>% unlist
  
  plot( mh_scale, sAccept_rate )
}

mean( sAccept )
#> [1] 0.42
hist( sPhi )
```

<img src="man/figures/README-run-1.png" width="100%" />

``` r
hist( sSigma2 )
```

<img src="man/figures/README-run-2.png" width="100%" />

``` r

summary( sPhi )
#>    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#>  0.1528  0.1759  0.1818  0.1834  0.1910  0.2125
summary( sSigma2 )
#>    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#>   1.638   1.946   2.032   2.042   2.109   2.516
summary( t( mBeta ) )
#>      incpt              x1               x2        
#>  Min.   : 9.002   Min.   :0.8924   Min.   :0.8711  
#>  1st Qu.:10.581   1st Qu.:0.9654   1st Qu.:0.9314  
#>  Median :10.949   Median :0.9888   Median :0.9555  
#>  Mean   :10.933   Mean   :0.9902   Mean   :0.9539  
#>  3rd Qu.:11.333   3rd Qu.:1.0153   3rd Qu.:0.9739  
#>  Max.   :12.533   Max.   :1.0817   Max.   :1.0906

plot( as.ts ( sPhi ) )
```

<img src="man/figures/README-run-3.png" width="100%" />

``` r
acf( sPhi )
```

<img src="man/figures/README-run-4.png" width="100%" />

``` r

raft = raftery.diag( sPhi, q=0.025, r=0.005, s=0.95, converge.eps=0.001)
print( raft ); raft$resmatrix
#> 
#> Quantile (q) = 0.025
#> Accuracy (r) = +/- 0.005
#> Probability (s) = 0.95 
#> 
#> You need a sample size of at least 3746 with these values of q, r and s
#> [1] "Error" "3746"

#gelman.diag( as.mcmc( sPhi ), confidence = 0.95, transform=FALSE, autoburnin=TRUE )
heidel.diag( as.mcmc( sPhi ), eps=0.1, pvalue=0.05)
#>                                    
#>      Stationarity start     p-value
#>      test         iteration        
#> var1 passed       1         0.838  
#>                               
#>      Halfwidth Mean  Halfwidth
#>      test                     
#> var1 passed    0.183 0.00294
geweke.diag( as.mcmc( sPhi ), frac1=0.1, frac2=0.5)
#> 
#> Fraction in 1st window = 0.1
#> Fraction in 2nd window = 0.5 
#> 
#>   var1 
#> 0.2857
```

You can also embed plots, for example:

<img src="man/figures/README-pressure-1.png" width="100%" />

In that case, don't forget to commit and push the resulting figure files, so they display on GitHub!
