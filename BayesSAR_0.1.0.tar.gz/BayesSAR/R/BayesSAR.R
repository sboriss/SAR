#' BayesSAR
#'
#' @description Bayesian estimation of Spatial AutoRegressive (SAR) model,
#' see De Oliveira and Song (2008)
#' The package is based on the OX code written by Dmitry Kulikov. The author
#' is grateful to Dmitry for sharing his code.
#'
#' @param opt - list of options for Monte Carlo simulation
#' @param y   - column vector, n x 1: dependent variable
#' @param x   - matrix, n x p: explanatory variables (including constant)
#' @param w   - spatial weight matrix (needs to be symmetric), n x n
#'
#' @return    - list summarising output of Monte Carlo simulation
#' @export
#'
#' @importFrom mvtnorm rmvnorm
#' @importFrom invgamma rinvgamma
#' @importFrom rlist list.remove
#'
#' @examples
#' BayesSAR( opt = NULL, y = matrix(5, ncol = 1, nrow = 5), x =1, w = 1 )
#'
BayesSAR <- function( opt, y, x, w ){

  nobs = dim( y )[1]; nobs
  nreg = dim( x )[2]; nreg

  mh_scale = opt$mh_scale

  ### extract eigenvalues from w
  w.eigen = eigen( w, symmetric = TRUE, only.values = FALSE, EISPACK = FALSE)
  sPhi.range = 1 / range( w.eigen$values ); sPhi.range

  sPhi.range = c( -6, 1 )

  ### set range of phi
  sPhi.low = ifelse( sPhi.range[1] < -1, -1,  sPhi.range[1] )
  sPhi.hgh = sPhi.range[2]

  ### initialize parameters
  sPhi = 0
  mSigmaPhiInv = diag( nobs )
  mXSXInv      = solve( t(x) %*% x )
  vBetaPhiHat  = mXSXInv %*% t(x) %*% y
  vRes         = y - x %*% vBetaPhiHat
  sSPhi2       = t( vRes ) %*% vRes

  m = matrix( rep( 1, 4 ), ncol = 2 )

  det( m )

  sLogD        = 0.5 * ( log( det( mSigmaPhiInv ) ) + log( det( mXSXInv ) ) ) - ( nobs - nreg ) / 2 * log( sSPhi2 ) ### (4.3) p. 335

  ### store simulation output
  mc_list = vector("list", length = opt$max_iter )

  mc_iter = list()
  mc_iter$vBeta       = 0
  mc_iter$sSigma2     = 0
  mc_iter$sPhi        = sPhi
  mc_iter$mXSXInv     = mXSXInv
  mc_iter$vBetaPhiHat = vBetaPhiHat
  mc_iter$sSPhi2      = sSPhi2
  mc_iter$sLogD       = sLogD
  mc_iter$sAccept     = 1

  mc_list[[1]] = mc_iter

  autotune_list = vector("list", length = opt$max_iter / 100 )
  ### START LOOP
  for( iter in 2:opt$max_iter ){ # iter = 8

    mc_iter_old = mc_list[[ iter - 1 ]]

    sPhi = mc_iter_old$sPhi

    ### STEP 1: MC RWMH step for Phi
    sPhiP = sPhi + rnorm( 1 ) * mh_scale
    if( sPhiP >= sPhi.hgh | sPhiP <= sPhi.low ){
      sLogDP = -Inf
    }else{
      mTemp = diag( nobs ) - w * sPhiP
      mSigmaPhiInv = mTemp %*% mTemp
      mXSXInv      = solve( t(x) %*% mSigmaPhiInv %*% x )
      vBetaPhiHat  = mXSXInv %*% ( t(x) %*% mSigmaPhiInv %*% y )
      vRes         = y - x %*% vBetaPhiHat
      sSPhi2       = t( vRes ) %*% mSigmaPhiInv %*% vRes


      ### robustify against log( det( 0 ) )
      log_det_mSigmaPhiInv = ifelse( det( mSigmaPhiInv ) > 0, log( det( mSigmaPhiInv ) ), 1e-10 )
      log_det_mXSXInv      = ifelse( det( mXSXInv      ) > 0, log( det( mXSXInv      ) ), 1e-10 )

      sLogDP        = 0.5 * ( log_det_mSigmaPhiInv + log_det_mXSXInv ) - ( nobs - nreg ) / 2 * log( sSPhi2 ) ### (4.3) p. 335

      #sLogDP        = 0.5 * ( log( det( mSigmaPhiInv ) ) + log( det( mXSXInv ) ) ) - ( nobs - nreg ) / 2 * log( sSPhi2 ) ### (4.3) p. 335

      rm( mSigmaPhiInv )
      rm( vRes )
      rm( mTemp )
    }

    ### STEP 2: CHECK IMPROVEMENT IN LOGLIK



    if( sLogDP - sLogD > log( runif( 1 ) ) ){
      sPhi    = sPhiP
      sLogD   = sLogDP
      sAccept = 1
    }else{
      mXSXInv      = mc_iter_old$mXSXInv
      vBetaPhiHat  = mc_iter_old$vBetaPhiHat
      sSPhi2       = mc_iter_old$sSPhi2
      sAccept      = 0
    }

    ### STEP 3: GIBBS SAMPLING FOR SIGMA2 AND BETA
    sSigma2 = rinvgamma(1, shape = ( nobs - nreg ) / 2, rate = sSPhi2 / 2  )
    vBeta   = vBetaPhiHat + rmvnorm( n=1, sigma = mXSXInv * sSigma2 ) %>% t

    mc_iter = list()
    mc_iter$vBeta       = vBeta
    mc_iter$sSigma2     = sSigma2
    mc_iter$sPhi        = sPhi
    mc_iter$mXSXInv     = mXSXInv
    mc_iter$vBetaPhiHat = vBetaPhiHat
    mc_iter$sSPhi2      = sSPhi2
    mc_iter$sLogD       = sLogD
    mc_iter$sAccept     = sAccept

    mc_list[[ iter ]] = mc_iter

    if( opt$autotune$execute &  !( iter %% 100 ) ){
      sAccept_hist = lapply( mc_list, `[[`, "sAccept" ) %>% unlist %>% tail( n = 100 )
      sAccept_rate = mean( sAccept_hist )
      cat( "\n\n*** Iteration:", iter,"from", opt$max_iter,"***" )
      cat( "\n*** Acceptance rate:", round( sAccept_rate * 100 ),"% ***" )
      sAccept_rate = ifelse( sAccept_rate > 0 & sAccept_rate < 1, sAccept_rate, 0.0001 )
      sMulti = sAccept_rate / opt$autotune$target_accept_MH;
      mh_scale = ifelse( abs( sMulti - 1 ) > 0.1, sMulti * mh_scale, mh_scale )
      cat( "\n*** sMulti:", sMulti," mh_scale:", mh_scale, "opt$mh_scale:",opt$mh_scale )
      autotune_list[[ iter / 100 ]] = list( sAccept_rate = sAccept_rate, mh_scale = mh_scale )
    }


  }
  length( mc_list )
  mc_list       = list.remove( mc_list      , seq( 1, opt$ini_iter) )
  autotune_list = list.remove( autotune_list, seq( 1, opt$ini_iter / 100 ) )
  length( mc_list )

  return( list( mc_list = mc_list, autotune_list = autotune_list ) )
}
